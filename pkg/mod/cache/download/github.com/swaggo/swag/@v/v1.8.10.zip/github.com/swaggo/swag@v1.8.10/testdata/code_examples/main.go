package main

// @title Swag test
// @version 1.0
// @description test for conflict name
func main() {

}
