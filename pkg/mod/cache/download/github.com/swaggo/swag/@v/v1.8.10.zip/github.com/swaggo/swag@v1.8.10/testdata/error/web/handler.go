package web

import (
	"github.com/swaggo/swag/testdata/error/errors"
)

type CrossErrors errors.Errors
