// Copyright 2020 The Godror Authors
//
// SPDX-License-Identifier: UPL-1.0 OR Apache-2.0

// +build require

// Package src contains required external dependencies from ODPI-C
package src
