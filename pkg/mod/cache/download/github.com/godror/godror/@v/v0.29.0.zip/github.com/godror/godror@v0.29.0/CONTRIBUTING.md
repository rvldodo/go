# Contribute
  1. Fork on github
  2. Check out the cloned codebase somewhere.
  3. Optionally, add the upstream source to be able to pull from: `git remote add upstream https://github.com/godror/godror.git`
  4. Modify as you wish
  5. Ensure that tests still pass, and add tests about your new code! 
  6. Commit with a nice describing message.
  7. Push it to your repo.
  8. Create a PR.
