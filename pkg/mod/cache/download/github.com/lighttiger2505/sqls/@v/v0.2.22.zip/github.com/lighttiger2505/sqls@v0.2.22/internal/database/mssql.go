package database

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/url"
	"strconv"

	_ "github.com/denisenkom/go-mssqldb"
	"github.com/lighttiger2505/sqls/dialect"
	"golang.org/x/crypto/ssh"
)

func init() {
	RegisterOpen("mssql", mssqlOpen)
	RegisterFactory("mssql", NewMssqlDBRepository)
}

func mssqlOpen(dbConnCfg *DBConfig) (*DBConnection, error) {
	var (
		conn    *sql.DB
		sshConn *ssh.Client
	)
	dsn, err := genMssqlConfig(dbConnCfg)
	if err != nil {
		return nil, err
	}

	if dbConnCfg.SSHCfg != nil {
		return nil, fmt.Errorf("connect via SSH is not supported")
	}
	dbConn, err := sql.Open("sqlserver", dsn)
	if err != nil {
		return nil, err
	}
	conn = dbConn
	if err = conn.Ping(); err != nil {
		return nil, err
	}

	conn.SetMaxIdleConns(DefaultMaxIdleConns)
	conn.SetMaxOpenConns(DefaultMaxOpenConns)

	return &DBConnection{
		Conn:    conn,
		SSHConn: sshConn,
	}, nil
}

type MssqlDBRepository struct {
	Conn *sql.DB
}

func NewMssqlDBRepository(conn *sql.DB) DBRepository {
	return &MssqlDBRepository{Conn: conn}
}

func (db *MssqlDBRepository) Driver() dialect.DatabaseDriver {
	return dialect.DatabaseDriverMssql
}

func (db *MssqlDBRepository) CurrentDatabase(ctx context.Context) (string, error) {
	row := db.Conn.QueryRowContext(ctx, "SELECT DB_NAME()")
	var database string
	if err := row.Scan(&database); err != nil {
		return "", err
	}
	return database, nil
}

func (db *MssqlDBRepository) Databases(ctx context.Context) ([]string, error) {
	rows, err := db.Conn.QueryContext(
		ctx,
		`
	SELECT name FROM sys.databases
	`)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	databases := []string{}
	for rows.Next() {
		var database string
		if err := rows.Scan(&database); err != nil {
			return nil, err
		}
		databases = append(databases, database)
	}
	return databases, nil
}

func (db *MssqlDBRepository) CurrentSchema(ctx context.Context) (string, error) {
	row := db.Conn.QueryRowContext(ctx, "SELECT SCHEMA_NAME()")
	var database sql.NullString
	if err := row.Scan(&database); err != nil {
		return "", err
	}
	if database.Valid {
		return database.String, nil
	}
	return "", nil
}

func (db *MssqlDBRepository) Schemas(ctx context.Context) ([]string, error) {
	rows, err := db.Conn.QueryContext(
		ctx,
		`
	SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA
	`)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	databases := []string{}
	for rows.Next() {
		var database string
		if err := rows.Scan(&database); err != nil {
			return nil, err
		}
		databases = append(databases, database)
	}
	return databases, nil
}

func (db *MssqlDBRepository) SchemaTables(ctx context.Context) (map[string][]string, error) {
	rows, err := db.Conn.QueryContext(
		ctx,
		`
	SELECT
		TABLE_SCHEMA,
		TABLE_NAME
	FROM
		INFORMATION_SCHEMA.TABLES
	ORDER BY
		TABLE_SCHEMA,
		TABLE_NAME
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	databaseTables := map[string][]string{}
	for rows.Next() {
		var schema, table string
		if err := rows.Scan(&schema, &table); err != nil {
			return nil, err
		}

		if arr, ok := databaseTables[schema]; ok {
			databaseTables[schema] = append(arr, table)
		} else {
			databaseTables[schema] = []string{table}
		}
	}
	return databaseTables, nil
}

func (db *MssqlDBRepository) Tables(ctx context.Context) ([]string, error) {
	rows, err := db.Conn.QueryContext(
		ctx,
		`
	SELECT
	  TABLE_NAME
	FROM
	  INFORMATION_SCHEMA.TABLES
	WHERE
	  TABLE_TYPE = 'BASE TABLE'
	  AND TABLE_SCHEMA NOT IN ('INFORMATION_SCHEMA', 'information_schema')
	ORDER BY
	  TABLE_NAME
	`)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	tables := []string{}
	for rows.Next() {
		var table string
		if err := rows.Scan(&table); err != nil {
			return nil, err
		}
		tables = append(tables, table)
	}
	return tables, nil
}

func (db *MssqlDBRepository) DescribeDatabaseTable(ctx context.Context) ([]*ColumnDesc, error) {
	rows, err := db.Conn.QueryContext(
		ctx,
		`
	SELECT
		c.TABLE_SCHEMA,
		c.TABLE_NAME,
		c.COLUMN_NAME,
		c.DATA_TYPE,
		c.IS_NULLABLE,
		CASE tc.CONSTRAINT_TYPE
			WHEN 'PRIMARY KEY' THEN 'YES'
			ELSE 'NO'
		END,
		c.COLUMN_DEFAULT,
		''
	FROM
		INFORMATION_SCHEMA.COLUMNS c
	LEFT JOIN
		INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu
		ON c.TABLE_NAME = ccu.TABLE_NAME
		AND c.COLUMN_NAME = ccu.COLUMN_NAME
	LEFT JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc ON
		tc.TABLE_CATALOG = c.TABLE_CATALOG
		AND tc.TABLE_SCHEMA = c.TABLE_SCHEMA
		AND tc.TABLE_NAME = c.TABLE_NAME
		AND tc.CONSTRAINT_NAME = ccu.CONSTRAINT_NAME
	ORDER BY
		c.TABLE_NAME,
		c.ORDINAL_POSITION
	`)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	tableInfos := []*ColumnDesc{}
	for rows.Next() {
		var tableInfo ColumnDesc
		err := rows.Scan(
			&tableInfo.Schema,
			&tableInfo.Table,
			&tableInfo.Name,
			&tableInfo.Type,
			&tableInfo.Null,
			&tableInfo.Key,
			&tableInfo.Default,
			&tableInfo.Extra,
		)
		if err != nil {
			return nil, err
		}
		tableInfos = append(tableInfos, &tableInfo)
	}
	return tableInfos, nil
}

func (db *MssqlDBRepository) DescribeDatabaseTableBySchema(ctx context.Context, schemaName string) ([]*ColumnDesc, error) {
	rows, err := db.Conn.QueryContext(
		ctx,
		`
	SELECT
		c.TABLE_SCHEMA,
		c.TABLE_NAME,
		c.COLUMN_NAME,
		c.DATA_TYPE,
		c.IS_NULLABLE,
		CASE tc.CONSTRAINT_TYPE
			WHEN 'PRIMARY KEY' THEN 'YES'
			ELSE 'NO'
		END,
		c.COLUMN_DEFAULT,
		''
	FROM
		INFORMATION_SCHEMA.COLUMNS c
	LEFT JOIN
		INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE ccu
		ON c.TABLE_NAME = ccu.TABLE_NAME
		AND c.COLUMN_NAME = ccu.COLUMN_NAME
	LEFT JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc ON
		tc.TABLE_CATALOG = c.TABLE_CATALOG
		AND tc.TABLE_SCHEMA = c.TABLE_SCHEMA
		AND tc.TABLE_NAME = c.TABLE_NAME
		AND tc.CONSTRAINT_NAME = ccu.CONSTRAINT_NAME
	WHERE
		c.TABLE_SCHEMA = $1
	ORDER BY
		c.TABLE_NAME,
		c.ORDINAL_POSITION
	`, schemaName)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	tableInfos := []*ColumnDesc{}
	for rows.Next() {
		var tableInfo ColumnDesc
		err := rows.Scan(
			&tableInfo.Schema,
			&tableInfo.Table,
			&tableInfo.Name,
			&tableInfo.Type,
			&tableInfo.Null,
			&tableInfo.Key,
			&tableInfo.Default,
			&tableInfo.Extra,
		)
		if err != nil {
			return nil, err
		}
		tableInfos = append(tableInfos, &tableInfo)
	}
	return tableInfos, nil
}

func (db *MssqlDBRepository) Exec(ctx context.Context, query string) (sql.Result, error) {
	return db.Conn.ExecContext(ctx, query)
}

func (db *MssqlDBRepository) Query(ctx context.Context, query string) (*sql.Rows, error) {
	return db.Conn.QueryContext(ctx, query)
}

func genMssqlConfig(connCfg *DBConfig) (string, error) {
	if connCfg.DataSourceName != "" {
		return connCfg.DataSourceName, nil
	}

	q := url.Values{}
	q.Set("user", connCfg.User)
	q.Set("password", connCfg.Passwd)
	q.Set("database", connCfg.DBName)

	switch connCfg.Proto {
	case ProtoTCP:
		host, port := connCfg.Host, connCfg.Port
		if host == "" {
			host = "127.0.0.1"
		}
		if port == 0 {
			port = 1433
		}
		q.Set("server", host)
		q.Set("port", strconv.Itoa(port))
	case ProtoUDP, ProtoUnix:
	default:
		return "", fmt.Errorf("default addr for network %s unknown", connCfg.Proto)
	}

	for k, v := range connCfg.Params {
		q.Set(k, v)
	}

	return genOptions(q, "", "=", ";", ",", true), nil
}
